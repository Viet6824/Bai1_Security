#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cctype>

std::vector<std::vector<char>> generatePlayfairMatrix(const std::string& key) {
    std::vector<std::vector<char>> matrix(5, std::vector<char>(5));
    std::string keyStr = key;
    std::transform(keyStr.begin(), keyStr.end(), keyStr.begin(), ::toupper);
    keyStr.erase(std::remove_if(keyStr.begin(), keyStr.end(),
                [](char c){ return !std::isalpha(c); }), keyStr.end());

    std::string alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"; // J gộp vào I
    std::vector<char> used;
    for(char c : keyStr) {
        if(std::find(used.begin(), used.end(), c) == used.end())
            used.push_back(c);
    }
    for(char c : alphabet) {
        if(std::find(used.begin(), used.end(), c) == used.end())
            used.push_back(c);
    }

    int idx = 0;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            matrix[i][j] = used[idx++];
        }
    }
    return matrix;
}

std::pair<int,int> findPosition(const std::vector<std::vector<char>>& matrix, char ch) {
    ch = toupper(ch);
    if(ch == 'J') ch = 'I';
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(matrix[i][j] == ch) return {i,j};
        }
    }
    return {-1,-1};
}

std::string playfairEncrypt(const std::string& text, const std::vector<std::vector<char>>& matrix) {
    std::string prepared = text;
    std::transform(prepared.begin(), prepared.end(), prepared.begin(), ::toupper);
    prepared.erase(std::remove_if(prepared.begin(), prepared.end(), [](char c){ return !isalpha(c); }), prepared.end());

    if(prepared.size() % 2 != 0) prepared += 'X'; // thêm X nếu lẻ

    std::string result = "";
    for(size_t i=0; i<prepared.size(); i+=2){
        char a = prepared[i], b = prepared[i+1];
        auto [r1,c1] = findPosition(matrix,a);
        auto [r2,c2] = findPosition(matrix,b);

        if(r1 == r2){
            result += matrix[r1][(c1+1)%5];
            result += matrix[r2][(c2+1)%5];
        } else if(c1 == c2){
            result += matrix[(r1+1)%5][c1];
            result += matrix[(r2+1)%5][c2];
        } else {
            result += matrix[r1][c2];
            result += matrix[r2][c1];
        }
    }
    return result;
}

std::string playfairDecrypt(const std::string& text, const std::vector<std::vector<char>>& matrix) {
    std::string prepared = text;
    std::transform(prepared.begin(), prepared.end(), prepared.begin(), ::toupper);

    std::string result = "";
    for(size_t i=0; i<prepared.size(); i+=2){
        char a = prepared[i], b = prepared[i+1];
        auto [r1,c1] = findPosition(matrix,a);
        auto [r2,c2] = findPosition(matrix,b);

        if(r1 == r2){
            result += matrix[r1][(c1-1+5)%5];
            result += matrix[r2][(c2-1+5)%5];
        } else if(c1 == c2){
            result += matrix[(r1-1+5)%5][c1];
            result += matrix[(r2-1+5)%5][c2];
        } else {
            result += matrix[r1][c2];
            result += matrix[r2][c1];
        }
    }
    return result;
}

int main() {
    std::string text, key;
    int choice;

    std::cout << "Nhap van ban (chi chu cai): ";
    std::getline(std::cin, text);

    std::cout << "Nhap khoa (chi chu cai, vi du: KEY): ";
    std::getline(std::cin, key);

    auto matrix = generatePlayfairMatrix(key);

    std::cout << "\nChon chuc nang:\n1. Ma hoa\n2. Giai ma\nNhap lua chon: ";
    std::cin >> choice;

    if(choice == 1){
        std::string encrypted = playfairEncrypt(text, matrix);
        std::cout << "Da ma hoa: " << encrypted << "\n";
    } else if(choice == 2){
        std::string decrypted = playfairDecrypt(text, matrix);
        std::cout << "Da giai ma: " << decrypted << "\n";
    } else {
        std::cout << "Lua chon khong hop le!\n";
    }

    return 0;
}
