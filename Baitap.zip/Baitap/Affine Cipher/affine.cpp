#include <iostream>
#include <string>

int modInverse(int a, int m) {
    for (int x = 1; x < m; x++) {
        if ((a * x) % m == 1) return x;
    }
    return 1; // fallback
}

std::string affineEncrypt(const std::string& text, int a, int b) {
    std::string result = text;
    const int MOD = 26;

    for (size_t i = 0; i < text.length(); i++) {
        char& ch = result[i];
        int base = 0;

        if (ch >= 'A' && ch <= 'Z') base = 'A';
        else if (ch >= 'a' && ch <= 'z') base = 'a';
        else continue;

        int x = ch - base;
        int newCode = (a * x + b) % MOD;
        if (newCode < 0) newCode += MOD;
        ch = static_cast<char>(newCode + base);
    }

    return result;
}

std::string affineDecrypt(const std::string& text, int a, int b) {
    std::string result = text;
    const int MOD = 26;
    int aInverse = modInverse(a, MOD);

    for (size_t i = 0; i < text.length(); i++) {
        char& ch = result[i];
        int base = 0;

        if (ch >= 'A' && ch <= 'Z') base = 'A';
        else if (ch >= 'a' && ch <= 'z') base = 'a';
        else continue;

        int x = ch - base;
        int newCode = (aInverse * (x - b)) % MOD;
        if (newCode < 0) newCode += MOD; // tránh số âm
        ch = static_cast<char>(newCode + base);
    }

    return result;
}

int main() {
    std::string text;
    int a, b, choice;

    std::cout << "Nhap van ban (chi A-Z, a-z): ";
    std::getline(std::cin, text);

    std::cout << "Nhap khoa a (1,3,5,7,9,11,15,17,19,21,23,25): ";
    std::cin >> a;

    std::cout << "Nhap khoa b (0 den 25): ";
    std::cin >> b;

    if (a != 1 && a != 3 && a != 5 && a != 7 && a != 9 && a != 11 &&
        a != 15 && a != 17 && a != 19 && a != 21 && a != 23 && a != 25) {
        std::cout << "Khong hop le! Khoa a phai la cac gia tri nguyen to cung 26." << std::endl;
        return 1;
    }
    if (b < 0 || b > 25) {
        std::cout << "Khong hop le! Khoa b phai tu 0 den 25." << std::endl;
        return 1;
    }

    std::cout << "Chon chuc nang (1 = Ma hoa, 2 = Giai ma): ";
    std::cin >> choice;

    if (choice == 1) {
        std::cout << "Da ma hoa: " << affineEncrypt(text, a, b) << std::endl;
    } else if (choice == 2) {
        std::cout << "Da giai ma: " << affineDecrypt(text, a, b) << std::endl;
    } else {
        std::cout << "Lua chon khong hop le!" << std::endl;
    }

    return 0;
}
