#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

// Bỏ khoảng trắng
std::string removeSpaces(const std::string& text) {
    std::string result;
    for (char c : text) {
        if (c != ' ') result += c;
    }
    return result;
}

// Tính thứ tự cột theo khóa
std::vector<int> keyOrder(const std::string& key) {
    std::vector<std::pair<char, int>> arr;
    for (int i = 0; i < key.length(); ++i) {
        arr.push_back({key[i], i});
    }
    std::sort(arr.begin(), arr.end(), [](const std::pair<char, int>& a, const std::pair<char, int>& b) {
        if (a.first != b.first) return a.first < b.first;
        return a.second < b.second;
    });
    std::vector<int> order;
    for (const auto& p : arr) {
        order.push_back(p.second);
    }
    return order;
}

// Mã hóa hoán vị cột
std::string encryptColumnar(const std::string& plaintext, const std::string& key, char padChar = 'X') {
    if (key.empty()) return plaintext;
    std::string cleanText = removeSpaces(plaintext);

    int m = key.length();
    int L = cleanText.length();
    int rows = (L + m - 1) / m;
    std::vector<std::vector<char>> matrix(rows, std::vector<char>(m, padChar));

    int pos = 0;
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < m; ++c) {
            if (pos < L) matrix[r][c] = cleanText[pos++];
        }
    }

    std::vector<int> order = keyOrder(key);
    std::string cipher = "";
    for (int k = 0; k < order.size(); ++k) {
        int c = order[k];
        for (int r = 0; r < rows; ++r) {
            cipher += matrix[r][c];
        }
    }
    return cipher;
}

// Giải mã hoán vị cột
std::string decryptColumnar(const std::string& ciphertext, const std::string& key, char padChar = 'X') {
    if (key.empty()) return ciphertext;
    std::string cleanCipher = removeSpaces(ciphertext);

    int m = key.length();
    int L = cleanCipher.length();
    int rows = (L + m - 1) / m;
    std::vector<std::vector<char>> matrix(rows, std::vector<char>(m, padChar));

    std::vector<int> order = keyOrder(key);

    int pos = 0;
    for (int k = 0; k < order.size(); ++k) {
        int c = order[k];
        for (int r = 0; r < rows; ++r) {
            if (pos < L) matrix[r][c] = cleanCipher[pos++];
        }
    }

    std::string plain = "";
    for (int r = 0; r < rows; ++r) {
        for (int c = 0; c < m; ++c) {
            plain += matrix[r][c];
        }
    }

    while (!plain.empty() && plain.back() == padChar) {
        plain.pop_back();
    }

    return plain;
}

int main() {
    std::string text, key;
    int choice;

    std::cout << "Nhap van ban (co the co khoang trang): ";
    std::getline(std::cin, text);

    std::cout << "Nhap khoa (vi du: KEY): ";
    std::getline(std::cin, key);

    std::cout << "Chon chuc nang (1 = Ma hoa, 2 = Giai ma): ";
    std::cin >> choice;

    if (choice == 1) {
        std::cout << "Da ma hoa: " << encryptColumnar(text, key) << std::endl;
    } else if (choice == 2) {
        std::cout << "Da giai ma: " << decryptColumnar(text, key) << std::endl;
    } else {
        std::cout << "Lua chon khong hop le!" << std::endl;
    }

    return 0;
}
