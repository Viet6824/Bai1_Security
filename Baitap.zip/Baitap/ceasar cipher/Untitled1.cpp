#include <iostream>
#include <string>

std::string caesarEncrypt(const std::string& text, int shift) {
    std::string result = text;
    const int MOD = 26;
    shift = shift % MOD;

    for (size_t i = 0; i < text.length(); i++) {
        char& ch = result[i];
        int base = 0;

        if (ch >= 'A' && ch <= 'Z') base = 'A';
        else if (ch >= 'a' && ch <= 'z') base = 'a';
        else continue;

        int newCode = (ch - base + shift) % MOD + base;
        ch = static_cast<char>(newCode);
    }
    return result;
}

std::string caesarDecrypt(const std::string& text, int shift) {
    std::string result = text;
    const int MOD = 26;
    shift = shift % MOD;

    for (size_t i = 0; i < text.length(); i++) {
        char& ch = result[i];
        int base = 0;

        if (ch >= 'A' && ch <= 'Z') base = 'A';
        else if (ch >= 'a' && ch <= 'z') base = 'a';
        else continue;

        int newCode = (ch - base - shift);
        if (newCode < 0) newCode += MOD;  // tránh âm
        newCode = newCode % MOD + base;
        ch = static_cast<char>(newCode);
    }
    return result;
}

int main() {
    std::string text;
    int shift;
    int choice;

    std::cout << "Nhap van ban: ";
    std::getline(std::cin, text);

    std::cout << "Nhap khoa dich (0-25): ";
    std::cin >> shift;

    std::cout << "Chon chuc nang (1 = Ma hoa, 2 = Giai ma): ";
    std::cin >> choice;

    if (choice == 1) {
        std::cout << "Da ma hoa: " << caesarEncrypt(text, shift) << std::endl;
    } else if (choice == 2) {
        std::cout << "Da giai ma: " << caesarDecrypt(text, shift) << std::endl;
    } else {
        std::cout << "Lua chon khong hop le!" << std::endl;
    }

    return 0;
}
