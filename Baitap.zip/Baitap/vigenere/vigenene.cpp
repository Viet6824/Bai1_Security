#include <iostream>
#include <string>
#include <cctype>

// Hàm Vigenère Cipher
std::string vigenereCipher(const std::string& text, const std::string& key, bool encrypt = true) {
    std::string result = text;
    int keyIndex = 0;

    for (size_t i = 0; i < text.length(); ++i) {
        char& ch = result[i];
        if (std::isalpha(ch)) { // chỉ xử lý chữ cái
            char base = std::isupper(ch) ? 'A' : 'a';
            int shift = std::toupper(key[keyIndex % key.length()]) - 'A';
            int code = ch - base;

            if (encrypt) {
                int newCode = (code + shift) % 26;
                ch = static_cast<char>(newCode + base);
            } else {
                int newCode = (code - shift + 26) % 26;
                ch = static_cast<char>(newCode + base);
            }
            keyIndex++;
        }
    }
    return result;
}

int main() {
    std::string text, key;
    int choice;

    std::cout << "Nhap van ban (co the co khoang trang): ";
    std::getline(std::cin, text);

    std::cout << "Nhap khoa (chi chu cai): ";
    std::getline(std::cin, key);

    // Kiểm tra khóa
    bool validKey = true;
    for (char c : key) {
        if (!std::isalpha(c)) {
            validKey = false;
            break;
        }
    }
    if (key.empty() || !validKey) {
        std::cout << "Khong hop le! Vui long nhap khoa chi chua chu cai." << std::endl;
        return 1;
    }

    std::cout << "Chon chuc nang (1 = Ma hoa, 2 = Giai ma): ";
    std::cin >> choice;

    if (choice == 1) {
        std::cout << "Da ma hoa: " << vigenereCipher(text, key, true) << std::endl;
    } else if (choice == 2) {
        std::cout << "Da giai ma: " << vigenereCipher(text, key, false) << std::endl;
    } else {
        std::cout << "Lua chon khong hop le!" << std::endl;
    }

    return 0;
}
